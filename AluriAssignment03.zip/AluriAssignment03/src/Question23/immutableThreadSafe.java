package Question23;

public class immutableThreadSafe {
	
	    private final int value;

	    public immutableThreadSafe(int value) {
	        this.value = value;
	    }

	    public int getValue() {
	        return value;
	    }
}
	



