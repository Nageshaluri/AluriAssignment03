package Question8;

public class tryWithoutCatch {
	    public static void main(String[] args) {
	        try {
	           
	        } finally {
	 
	        }
	    }
	}

