package Question7;
public class constructorFinal {
	    public final void my() {
	    }
	    public final int Var = 10;
	    
	    public final constructorFinal() {
	    	
	    }
	}

